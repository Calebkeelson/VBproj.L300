﻿Public Class frmoffertory

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub DomainUpDown1_SelectedItemChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtofftype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbofftype.SelectedIndexChanged

    End Sub
End Class