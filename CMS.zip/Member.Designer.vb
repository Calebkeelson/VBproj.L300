﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmember
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtoccupation = New System.Windows.Forms.TextBox()
        Me.txtmemaddress = New System.Windows.Forms.TextBox()
        Me.txtlname = New System.Windows.Forms.TextBox()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.txtmemid = New System.Windows.Forms.TextBox()
        Me.dtpdateofbirth = New System.Windows.Forms.DateTimePicker()
        Me.cbgenmale = New System.Windows.Forms.CheckBox()
        Me.cbgenfemale = New System.Windows.Forms.CheckBox()
        Me.cbbaptizedyes = New System.Windows.Forms.CheckBox()
        Me.cbbaptizedno = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Member Id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 150)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Last Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Date of Birth"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 295)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Address"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 197)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Gender"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 365)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Occupation"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 414)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Baptized"
        '
        'txtoccupation
        '
        Me.txtoccupation.Location = New System.Drawing.Point(146, 365)
        Me.txtoccupation.Name = "txtoccupation"
        Me.txtoccupation.Size = New System.Drawing.Size(200, 22)
        Me.txtoccupation.TabIndex = 8
        '
        'txtmemaddress
        '
        Me.txtmemaddress.Location = New System.Drawing.Point(146, 295)
        Me.txtmemaddress.Multiline = True
        Me.txtmemaddress.Name = "txtmemaddress"
        Me.txtmemaddress.Size = New System.Drawing.Size(200, 47)
        Me.txtmemaddress.TabIndex = 9
        '
        'txtlname
        '
        Me.txtlname.Location = New System.Drawing.Point(146, 150)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(264, 22)
        Me.txtlname.TabIndex = 12
        '
        'txtfname
        '
        Me.txtfname.Location = New System.Drawing.Point(146, 99)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(264, 22)
        Me.txtfname.TabIndex = 13
        '
        'txtmemid
        '
        Me.txtmemid.Location = New System.Drawing.Point(146, 50)
        Me.txtmemid.Name = "txtmemid"
        Me.txtmemid.Size = New System.Drawing.Size(100, 22)
        Me.txtmemid.TabIndex = 14
        '
        'dtpdateofbirth
        '
        Me.dtpdateofbirth.Location = New System.Drawing.Point(146, 247)
        Me.dtpdateofbirth.Name = "dtpdateofbirth"
        Me.dtpdateofbirth.Size = New System.Drawing.Size(200, 22)
        Me.dtpdateofbirth.TabIndex = 16
        '
        'cbgenmale
        '
        Me.cbgenmale.AutoSize = True
        Me.cbgenmale.Location = New System.Drawing.Point(146, 197)
        Me.cbgenmale.Name = "cbgenmale"
        Me.cbgenmale.Size = New System.Drawing.Size(60, 21)
        Me.cbgenmale.TabIndex = 17
        Me.cbgenmale.Text = "Male"
        Me.cbgenmale.UseVisualStyleBackColor = True
        '
        'cbgenfemale
        '
        Me.cbgenfemale.AutoSize = True
        Me.cbgenfemale.Location = New System.Drawing.Point(246, 197)
        Me.cbgenfemale.Name = "cbgenfemale"
        Me.cbgenfemale.Size = New System.Drawing.Size(76, 21)
        Me.cbgenfemale.TabIndex = 18
        Me.cbgenfemale.Text = "Female"
        Me.cbgenfemale.UseVisualStyleBackColor = True
        '
        'cbbaptizedyes
        '
        Me.cbbaptizedyes.AutoSize = True
        Me.cbbaptizedyes.Location = New System.Drawing.Point(146, 414)
        Me.cbbaptizedyes.Name = "cbbaptizedyes"
        Me.cbbaptizedyes.Size = New System.Drawing.Size(54, 21)
        Me.cbbaptizedyes.TabIndex = 19
        Me.cbbaptizedyes.Text = "Yes"
        Me.cbbaptizedyes.UseVisualStyleBackColor = True
        '
        'cbbaptizedno
        '
        Me.cbbaptizedno.AutoSize = True
        Me.cbbaptizedno.Location = New System.Drawing.Point(215, 414)
        Me.cbbaptizedno.Name = "cbbaptizedno"
        Me.cbbaptizedno.Size = New System.Drawing.Size(48, 21)
        Me.cbbaptizedno.TabIndex = 20
        Me.cbbaptizedno.Text = "No"
        Me.cbbaptizedno.UseVisualStyleBackColor = True
        '
        'frmmember
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1110, 567)
        Me.Controls.Add(Me.cbbaptizedno)
        Me.Controls.Add(Me.cbbaptizedyes)
        Me.Controls.Add(Me.cbgenfemale)
        Me.Controls.Add(Me.cbgenmale)
        Me.Controls.Add(Me.dtpdateofbirth)
        Me.Controls.Add(Me.txtmemid)
        Me.Controls.Add(Me.txtfname)
        Me.Controls.Add(Me.txtlname)
        Me.Controls.Add(Me.txtmemaddress)
        Me.Controls.Add(Me.txtoccupation)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmmember"
        Me.Text = "Member"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtoccupation As System.Windows.Forms.TextBox
    Friend WithEvents txtmemaddress As System.Windows.Forms.TextBox
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents txtfname As System.Windows.Forms.TextBox
    Friend WithEvents txtmemid As System.Windows.Forms.TextBox
    Friend WithEvents dtpdateofbirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents cbgenmale As System.Windows.Forms.CheckBox
    Friend WithEvents cbgenfemale As System.Windows.Forms.CheckBox
    Friend WithEvents cbbaptizedyes As System.Windows.Forms.CheckBox
    Friend WithEvents cbbaptizedno As System.Windows.Forms.CheckBox
End Class
