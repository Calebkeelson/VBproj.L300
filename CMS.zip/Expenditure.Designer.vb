﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmexpenditure
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtexid = New System.Windows.Forms.TextBox()
        Me.txtextype = New System.Windows.Forms.TextBox()
        Me.txtexamt = New System.Windows.Forms.TextBox()
        Me.txtexdescription = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Expenditure ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(119, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Expenditure Type"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 162)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Amount"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 244)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Description"
        '
        'txtexid
        '
        Me.txtexid.Location = New System.Drawing.Point(176, 41)
        Me.txtexid.Name = "txtexid"
        Me.txtexid.Size = New System.Drawing.Size(172, 22)
        Me.txtexid.TabIndex = 4
        '
        'txtextype
        '
        Me.txtextype.Location = New System.Drawing.Point(176, 98)
        Me.txtextype.Name = "txtextype"
        Me.txtextype.Size = New System.Drawing.Size(172, 22)
        Me.txtextype.TabIndex = 5
        '
        'txtexamt
        '
        Me.txtexamt.Location = New System.Drawing.Point(176, 162)
        Me.txtexamt.Name = "txtexamt"
        Me.txtexamt.Size = New System.Drawing.Size(172, 22)
        Me.txtexamt.TabIndex = 6
        '
        'txtexdescription
        '
        Me.txtexdescription.Location = New System.Drawing.Point(176, 239)
        Me.txtexdescription.Name = "txtexdescription"
        Me.txtexdescription.Size = New System.Drawing.Size(172, 22)
        Me.txtexdescription.TabIndex = 7
        '
        'frmexpenditure
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1005, 650)
        Me.Controls.Add(Me.txtexdescription)
        Me.Controls.Add(Me.txtexamt)
        Me.Controls.Add(Me.txtextype)
        Me.Controls.Add(Me.txtexid)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmexpenditure"
        Me.Text = "Expenditure"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtexid As System.Windows.Forms.TextBox
    Friend WithEvents txtextype As System.Windows.Forms.TextBox
    Friend WithEvents txtexamt As System.Windows.Forms.TextBox
    Friend WithEvents txtexdescription As System.Windows.Forms.TextBox
End Class
