﻿Public Class frmexpenditure

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtitemname.TextChanged

    End Sub

    Private Sub frmexpenditure_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class