﻿Public Class frmexpenditure

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtextype.TextChanged

    End Sub
End Class