﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmoffertory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtmemid = New System.Windows.Forms.TextBox()
        Me.txtoffamount = New System.Windows.Forms.TextBox()
        Me.txtoffid = New System.Windows.Forms.TextBox()
        Me.cmbofftype = New System.Windows.Forms.ComboBox()
        Me.txtaccdetails = New System.Windows.Forms.TextBox()
        Me.txtmemname = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Offering ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 138)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Offering Type"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Accouunt Details"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 299)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Amount"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(44, 368)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Member ID"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(44, 441)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Member Name"
        '
        'txtmemid
        '
        Me.txtmemid.Location = New System.Drawing.Point(168, 368)
        Me.txtmemid.Name = "txtmemid"
        Me.txtmemid.Size = New System.Drawing.Size(142, 22)
        Me.txtmemid.TabIndex = 6
        '
        'txtoffamount
        '
        Me.txtoffamount.Location = New System.Drawing.Point(168, 299)
        Me.txtoffamount.Name = "txtoffamount"
        Me.txtoffamount.Size = New System.Drawing.Size(142, 22)
        Me.txtoffamount.TabIndex = 7
        '
        'txtoffid
        '
        Me.txtoffid.Location = New System.Drawing.Point(168, 68)
        Me.txtoffid.Name = "txtoffid"
        Me.txtoffid.Size = New System.Drawing.Size(142, 22)
        Me.txtoffid.TabIndex = 9
        '
        'cmbofftype
        '
        Me.cmbofftype.FormattingEnabled = True
        Me.cmbofftype.Items.AddRange(New Object() {"Tithe", "Thanksgiving Offering", "Denominational Offering", "Free will Offering"})
        Me.cmbofftype.Location = New System.Drawing.Point(168, 135)
        Me.cmbofftype.Name = "cmbofftype"
        Me.cmbofftype.Size = New System.Drawing.Size(142, 24)
        Me.cmbofftype.TabIndex = 10
        '
        'txtaccdetails
        '
        Me.txtaccdetails.Location = New System.Drawing.Point(168, 221)
        Me.txtaccdetails.Multiline = True
        Me.txtaccdetails.Name = "txtaccdetails"
        Me.txtaccdetails.Size = New System.Drawing.Size(142, 64)
        Me.txtaccdetails.TabIndex = 11
        '
        'txtmemname
        '
        Me.txtmemname.Location = New System.Drawing.Point(168, 436)
        Me.txtmemname.Name = "txtmemname"
        Me.txtmemname.Size = New System.Drawing.Size(142, 22)
        Me.txtmemname.TabIndex = 12
        '
        'frmoffertory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1084, 698)
        Me.Controls.Add(Me.txtmemname)
        Me.Controls.Add(Me.txtaccdetails)
        Me.Controls.Add(Me.cmbofftype)
        Me.Controls.Add(Me.txtoffid)
        Me.Controls.Add(Me.txtoffamount)
        Me.Controls.Add(Me.txtmemid)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmoffertory"
        Me.Text = "Offertory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtmemid As System.Windows.Forms.TextBox
    Friend WithEvents txtoffamount As System.Windows.Forms.TextBox
    Friend WithEvents txtoffid As System.Windows.Forms.TextBox
    Friend WithEvents cmbofftype As System.Windows.Forms.ComboBox
    Friend WithEvents txtaccdetails As System.Windows.Forms.TextBox
    Friend WithEvents txtmemname As System.Windows.Forms.TextBox
End Class
