﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmchurch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtchfounder = New System.Windows.Forms.TextBox()
        Me.txtpastorid = New System.Windows.Forms.TextBox()
        Me.txtchaddress = New System.Windows.Forms.TextBox()
        Me.txtchname = New System.Windows.Forms.TextBox()
        Me.txtpastorname = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Church Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 174)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Founder"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 222)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Pastor ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 285)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Pastor Name"
        '
        'txtchfounder
        '
        Me.txtchfounder.Location = New System.Drawing.Point(137, 174)
        Me.txtchfounder.Name = "txtchfounder"
        Me.txtchfounder.Size = New System.Drawing.Size(281, 22)
        Me.txtchfounder.TabIndex = 5
        '
        'txtpastorid
        '
        Me.txtpastorid.Location = New System.Drawing.Point(137, 222)
        Me.txtpastorid.Name = "txtpastorid"
        Me.txtpastorid.Size = New System.Drawing.Size(100, 22)
        Me.txtpastorid.TabIndex = 6
        '
        'txtchaddress
        '
        Me.txtchaddress.Location = New System.Drawing.Point(137, 98)
        Me.txtchaddress.Multiline = True
        Me.txtchaddress.Name = "txtchaddress"
        Me.txtchaddress.Size = New System.Drawing.Size(281, 54)
        Me.txtchaddress.TabIndex = 7
        '
        'txtchname
        '
        Me.txtchname.Location = New System.Drawing.Point(137, 32)
        Me.txtchname.Name = "txtchname"
        Me.txtchname.Size = New System.Drawing.Size(281, 22)
        Me.txtchname.TabIndex = 8
        '
        'txtpastorname
        '
        Me.txtpastorname.Location = New System.Drawing.Point(137, 285)
        Me.txtpastorname.Name = "txtpastorname"
        Me.txtpastorname.Size = New System.Drawing.Size(281, 22)
        Me.txtpastorname.TabIndex = 6
        '
        'frmchurch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(631, 491)
        Me.Controls.Add(Me.txtchname)
        Me.Controls.Add(Me.txtchaddress)
        Me.Controls.Add(Me.txtpastorname)
        Me.Controls.Add(Me.txtpastorid)
        Me.Controls.Add(Me.txtchfounder)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmchurch"
        Me.Text = "Church"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtchfounder As System.Windows.Forms.TextBox
    Friend WithEvents txtpastorid As System.Windows.Forms.TextBox
    Friend WithEvents txtchaddress As System.Windows.Forms.TextBox
    Friend WithEvents txtchname As System.Windows.Forms.TextBox
    Friend WithEvents txtpastorname As System.Windows.Forms.TextBox

End Class
