﻿Public Class frmchurch

    Private Sub frmchurch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
