﻿Public Class frmtestimony

    Private Sub frmtestimonies_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtmemid_TextChanged(sender As Object, e As EventArgs) Handles txtmemid.TextChanged

    End Sub
End Class