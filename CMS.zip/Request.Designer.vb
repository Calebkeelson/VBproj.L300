﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmrequest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.txtmemname = New System.Windows.Forms.TextBox()
        Me.txtreqmessage = New System.Windows.Forms.TextBox()
        Me.txtreqtype = New System.Windows.Forms.TextBox()
        Me.txtreqstatus = New System.Windows.Forms.TextBox()
        Me.txtreqid = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 84)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Request ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 146)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Request Type"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 203)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Message"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(48, 393)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Status"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(48, 464)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Member Name"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(748, 557)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 5
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(432, 557)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 6
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'txtmemname
        '
        Me.txtmemname.Location = New System.Drawing.Point(196, 464)
        Me.txtmemname.Name = "txtmemname"
        Me.txtmemname.Size = New System.Drawing.Size(100, 22)
        Me.txtmemname.TabIndex = 7
        '
        'txtreqmessage
        '
        Me.txtreqmessage.Location = New System.Drawing.Point(196, 198)
        Me.txtreqmessage.Name = "txtreqmessage"
        Me.txtreqmessage.Size = New System.Drawing.Size(100, 22)
        Me.txtreqmessage.TabIndex = 8
        '
        'txtreqtype
        '
        Me.txtreqtype.Location = New System.Drawing.Point(196, 146)
        Me.txtreqtype.Name = "txtreqtype"
        Me.txtreqtype.Size = New System.Drawing.Size(100, 22)
        Me.txtreqtype.TabIndex = 9
        '
        'txtreqstatus
        '
        Me.txtreqstatus.Location = New System.Drawing.Point(196, 393)
        Me.txtreqstatus.Name = "txtreqstatus"
        Me.txtreqstatus.Size = New System.Drawing.Size(100, 22)
        Me.txtreqstatus.TabIndex = 10
        '
        'txtreqid
        '
        Me.txtreqid.Location = New System.Drawing.Point(196, 84)
        Me.txtreqid.Name = "txtreqid"
        Me.txtreqid.Size = New System.Drawing.Size(100, 22)
        Me.txtreqid.TabIndex = 11
        '
        'frmrequest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1001, 669)
        Me.Controls.Add(Me.txtreqid)
        Me.Controls.Add(Me.txtreqstatus)
        Me.Controls.Add(Me.txtreqtype)
        Me.Controls.Add(Me.txtreqmessage)
        Me.Controls.Add(Me.txtmemname)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmrequest"
        Me.Text = "Request"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents txtmemname As System.Windows.Forms.TextBox
    Friend WithEvents txtreqmessage As System.Windows.Forms.TextBox
    Friend WithEvents txtreqtype As System.Windows.Forms.TextBox
    Friend WithEvents txtreqstatus As System.Windows.Forms.TextBox
    Friend WithEvents txtreqid As System.Windows.Forms.TextBox
End Class
