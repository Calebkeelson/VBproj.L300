﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmtestimony
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txttestid = New System.Windows.Forms.TextBox()
        Me.txtmemname = New System.Windows.Forms.TextBox()
        Me.txttestdata = New System.Windows.Forms.TextBox()
        Me.txtmemid = New System.Windows.Forms.TextBox()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Testimony ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Testimony Data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 261)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Member ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 331)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Member Name"
        '
        'txttestid
        '
        Me.txttestid.Location = New System.Drawing.Point(180, 31)
        Me.txttestid.Name = "txttestid"
        Me.txttestid.Size = New System.Drawing.Size(100, 22)
        Me.txttestid.TabIndex = 4
        '
        'txtmemname
        '
        Me.txtmemname.Location = New System.Drawing.Point(180, 331)
        Me.txtmemname.Name = "txtmemname"
        Me.txtmemname.Size = New System.Drawing.Size(100, 22)
        Me.txtmemname.TabIndex = 5
        '
        'txttestdata
        '
        Me.txttestdata.Location = New System.Drawing.Point(180, 87)
        Me.txttestdata.Multiline = True
        Me.txttestdata.Name = "txttestdata"
        Me.txttestdata.Size = New System.Drawing.Size(380, 148)
        Me.txttestdata.TabIndex = 6
        '
        'txtmemid
        '
        Me.txtmemid.Location = New System.Drawing.Point(180, 261)
        Me.txtmemid.Name = "txtmemid"
        Me.txtmemid.Size = New System.Drawing.Size(100, 22)
        Me.txtmemid.TabIndex = 7
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Location = New System.Drawing.Point(539, 87)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(21, 148)
        Me.VScrollBar1.TabIndex = 8
        '
        'frmtestimony
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(927, 632)
        Me.Controls.Add(Me.VScrollBar1)
        Me.Controls.Add(Me.txtmemid)
        Me.Controls.Add(Me.txttestdata)
        Me.Controls.Add(Me.txtmemname)
        Me.Controls.Add(Me.txttestid)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmtestimony"
        Me.Text = "Testimony"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txttestid As System.Windows.Forms.TextBox
    Friend WithEvents txtmemname As System.Windows.Forms.TextBox
    Friend WithEvents txttestdata As System.Windows.Forms.TextBox
    Friend WithEvents txtmemid As System.Windows.Forms.TextBox
    Friend WithEvents VScrollBar1 As System.Windows.Forms.VScrollBar
End Class
